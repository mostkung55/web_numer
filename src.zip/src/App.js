import React from 'react';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import {  Route, Routes,BrowserRouter } from "react-router-dom";
import Home from "./Element/Home";
import NavbarComp from "./components/NavbarComp";
import About from "./Element/About";
import Bisection from "./Element/Bisection";

function App() {
  return (
    <div className="App">
    <NavbarComp/> 
    <BrowserRouter>
  <Routes>
    <Route path="/ " element={<Home />}/>
    <Route path="/Home" element={<Home />}/>
      <Route path="/About" element={<About />} />
      <Route path="/Bisection" element={<Bisection />} />

    </Routes>
</BrowserRouter>
  </div>
  );
}

export default App;