import React from "react";
import  { Button,Form }  from "react-bootstrap";


function Bisection () {

return(
    <div>
        <h1>Bisection</h1>
            <Form>
                
                <Form.Group className="mb-3" style={{  margin: " auto " }} >      
                    <Form.Label>In put Number </Form.Label>

                    <Form.Control id ="FX"  style={{width : "20%", margin : " auto " }} placeholder="FX"/>   
                    <Form.Control id ="XR"  style={{width : "20%", margin : " auto" }} placeholder="XR"/> 
                    <Form.Control id ="XL"  style={{width : "20%", margin : " auto" }} placeholder="XL"/>

                </Form.Group>
                <Button>
                        Submit
                </Button>

            </Form>
        </div>

)




}

export default Bisection;