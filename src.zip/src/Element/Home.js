import React from "react";
//import { Nav } from "react-bootstrap";
//import { Link } from "react-router-dom";
//import Navbar from "./components/NavbarComp";
const Home = () => {
  return (
    <div>
      <h1>kuy kuy project</h1>
      <p>isus </p>
    </div>
  );
};
export default Home;