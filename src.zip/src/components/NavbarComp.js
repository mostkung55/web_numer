import React  from 'react';
import { Navbar,Nav,NavDropdown,Container} from 'react-bootstrap';

const NavbarComp = () => {
    
        return(
          
            <>
            <div>
            <Navbar bg="dark" variant="dark"  expand="lg">
      <Container>
        <Navbar.Brand href="/Home" >Kanyapatch</Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="me-auto">
            <Nav.Link href="/Home">Home</Nav.Link>
            <Nav.Link  href="/About">About</Nav.Link>
            <NavDropdown title="Roots of Equations" id="basic-nav-dropdown">
              <NavDropdown.Item href="/Bisection">Bisection</NavDropdown.Item>
              <NavDropdown.Item href="#False Position">False Position</NavDropdown.Item>
              <NavDropdown.Item href="#One Point iteration">One Point iteration</NavDropdown.Item>
              <NavDropdown.Item href="#Newton Raphson">Newton Raphson</NavDropdown.Item>
              <NavDropdown.Item href="#Secant">Secant</NavDropdown.Item>
            </NavDropdown>

            <NavDropdown title="Linear Algebra" id="basic-nav-dropdown">
            <NavDropdown.Item href="#Cramer's Rule">Cramer's Rule</NavDropdown.Item>
            <NavDropdown.Item href="#Gauss Elimination">Gauss Elimination</NavDropdown.Item>
            <NavDropdown.Item href="#Gauss Joradan">Gauss Joradan</NavDropdown.Item>
            <NavDropdown.Item href="#LU Decomposition">LU Decomposition</NavDropdown.Item>
            <NavDropdown.Item href="#Cholesky Decomposition">Cholesky Decomposition</NavDropdown.Item>
            <NavDropdown.Item href="#Jacodi Iteration">Jacodi Iteration</NavDropdown.Item>
            <NavDropdown.Item href="#Gauss Seidel Lteration">Gauss Seidel Lteration</NavDropdown.Item>
            </NavDropdown>

            <NavDropdown title="Interpolation" id="basic-nav-dropdown">
            <NavDropdown.Item href="#Linear">Linear</NavDropdown.Item>
            <NavDropdown.Item href="#Quadratic">Quadratic</NavDropdown.Item>
            <NavDropdown.Item href="#Polynomial">Polynomial</NavDropdown.Item>
            <NavDropdown.Item href="#Spline">Spline</NavDropdown.Item>
            </NavDropdown>

            <NavDropdown title="Least Square Regression" id="basic-nav-dropdown">
            <NavDropdown.Item href="#Linear">Linear</NavDropdown.Item>
            <NavDropdown.Item href="#Polynomial">Polynomial</NavDropdown.Item>
            <NavDropdown.Item href="#Multiple Linear">Multiple Linear</NavDropdown.Item>
            </NavDropdown>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>

          </div>
        
   
          </>
        )
        
    

}
export default NavbarComp;